/* Load this script using conditional IE comments if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
			'icon-key' : '&#x63;',
			'icon-bar' : '&#x66;',
			'icon-bullhorn' : '&#x67;',
			'icon-burger' : '&#x68;',
			'icon-cog' : '&#x69;',
			'icon-dollar' : '&#x6a;',
			'icon-fries' : '&#x6e;',
			'icon-thumbs-up' : '&#x6f;',
			'icon-spatula' : '&#x70;',
			'icon-soda' : '&#x71;',
			'icon-smiley' : '&#x72;',
			'icon-pie' : '&#x74;',
			'icon-line' : '&#x75;',
			'icon-key-2' : '&#x76;',
			'icon-ice-cream-cone' : '&#x77;',
			'icon-handshake' : '&#x78;',
			'icon-hand' : '&#x79;',
			'icon-hammer' : '&#x7a;',
			'icon-eye' : '&#x64;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, html, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
};