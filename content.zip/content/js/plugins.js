// Avoid `console` errors in browsers that lack a console.
(function() {
	var method;
	var noop = function () {};
	var methods = [
		'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
		'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
		'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
		'timeStamp', 'trace', 'warn'
	];
	var length = methods.length;
	var console = (window.console = window.console || {});

	while (length--) {
		method = methods[length];

		// Only stub undefined methods.
		if (!console[method]) {
			console[method] = noop;
		}
	}
}());

// Place any jQuery/helper plugins in here.

/**
 * Arctext.js
 * A jQuery plugin for curved text
 * http://www.codrops.com
 *
 * Copyright 2011, Pedro Botelho / Codrops
 * Free to use under the MIT license.
 *
 * Date: Mon Jan 23 2012
 */

(function ($, undefined) {

	/*!	
	* FitText.js 1.0
	*
	* Copyright 2011, Dave Rupert http://daverupert.com
	* Released under the WTFPL license 
	* http://sam.zoy.org/wtfpl/
	*
	* Date: Thu May 05 14:23:00 2011 -0600
	*/
	$.fn.fitText = function (kompressor, options) {

		var settings = {
			'minFontSize': Number.NEGATIVE_INFINITY,
			'maxFontSize': Number.POSITIVE_INFINITY
		};

		return this.each(function () {
			var $this = $(this);              // store the object
			var compressor = kompressor || 1; // set the compressor

			if (options) {
				$.extend(settings, options);
			}

			// Resizer() resizes items based on the object width divided by the compressor * 10
			var resizer = function () {
				$this.css('font-size', Math.max(Math.min($this.width() / (compressor * 10), parseFloat(settings.maxFontSize)), parseFloat(settings.minFontSize)));
			};

			// Call once to set.
			resizer();

			// Call on resize. Opera debounces their resize by default. 
			$(window).resize(resizer);
		});

	};

	/*
	 * Lettering plugin
	 *
	 * changed injector function:
	 *   add &nbsp; for empty chars.
	 */
	function injector(t, splitter, klass, after) {
		var a = t.text().split(splitter), inject = '', emptyclass;
		if (a.length) {
			$(a).each(function (i, item) {
				emptyclass = '';
				if (item === ' ') {
					emptyclass = ' empty';
					item = '&nbsp;';
				}
				inject += '<span class="' + klass + (i + 1) + emptyclass + '">' + item + '</span>' + after;
			});
			t.empty().append(inject);
		}
	}

	var methods = {
		init: function () {

			return this.each(function () {
				injector($(this), '', 'char', '');
			});

		},

		words: function () {

			return this.each(function () {
				injector($(this), ' ', 'word', ' ');
			});

		},

		lines: function () {

			return this.each(function () {
				var r = "eefec303079ad17405c889e092e105b0";
				// Because it's hard to split a <br/> tag consistently across browsers,
				// (*ahem* IE *ahem*), we replaces all <br/> instances with an md5 hash 
				// (of the word "split").  If you're trying to use this plugin on that 
				// md5 hash string, it will fail because you're being ridiculous.
				injector($(this).children("br").replaceWith(r).end(), r, 'line', '');
			});

		}
	};

	$.fn.lettering = function (method) {
		// Method calling logic
		if (method && methods[method]) {
			return methods[method].apply(this, [].slice.call(arguments, 1));
		} else if (method === 'letters' || !method) {
			return methods.init.apply(this, [].slice.call(arguments, 0)); // always pass an array
		}
		$.error('Method ' + method + ' does not exist on jQuery.lettering');
		return this;
	};

	/*
	 * Arctext object.
	 */
	$.Arctext = function (options, element) {

		this.$el = $(element);
		this._init(options);

	};

	$.Arctext.defaults = {
		radius: 0, 	// the minimum value allowed is half of the word length. if set to -1, the word will be straight.
		dir: 1,	// 1: curve is down, -1: curve is up.
		rotate: true,	// if true each letter will be rotated.
		fitText: false // if you wanna try out the fitText plugin (http://fittextjs.com/) set this to true. Don't forget the wrapper should be fluid.
	};

	$.Arctext.prototype = {
		_init: function (options) {

			this.options = $.extend(true, {}, $.Arctext.defaults, options);

			// apply the lettering plugin.
			this._applyLettering();

			this.$el.data('arctext', true);

			// calculate values
			this._calc();

			// apply transformation.
			this._rotateWord();

			// load the events
			this._loadEvents();

		},
		_applyLettering: function () {

			this.$el.lettering();

			if (this.options.fitText)
				this.$el.fitText();

			this.$letters = this.$el.find('span').css('display', 'inline-block');

		},
		_calc: function () {

			if (this.options.radius === -1)
				return false;

			// calculate word / arc sizes & distances.
			this._calcBase();

			// get final values for each letter.
			this._calcLetters();

		},
		_calcBase: function () {

			// total word width (sum of letters widths)
			this.dtWord = 0;

			var _self = this;

			this.$letters.each(function (i) {

				var $letter = $(this),
					letterWidth = $letter.outerWidth(true);

				_self.dtWord += letterWidth;

				// save the center point of each letter:
				$letter.data('center', _self.dtWord - letterWidth / 2);

			});

			// the middle point of the word.
			var centerWord = this.dtWord / 2;

			// check radius : the minimum value allowed is half of the word length.
			if (this.options.radius < centerWord)
				this.options.radius = centerWord;

			// total arc segment length, where the letters will be placed.
			this.dtArcBase = this.dtWord;

			// calculate the arc (length) that goes from the beginning of the first letter (x=0) to the end of the last letter (x=this.dtWord).
			// first lets calculate the angle for the triangle with base = this.dtArcBase and the other two sides = radius.
			var angle = 2 * Math.asin(this.dtArcBase / (2 * this.options.radius));

			// given the formula: L(ength) = R(adius) x A(ngle), we calculate our arc length.
			this.dtArc = this.options.radius * angle;

		},
		_calcLetters: function () {

			var _self = this,
				iteratorX = 0;

			this.$letters.each(function (i) {

				var $letter = $(this),
					// calculate each letter's semi arc given the percentage of each letter on the original word.
					dtArcLetter = ($letter.outerWidth(true) / _self.dtWord) * _self.dtArc,
					// angle for the dtArcLetter given our radius.
					beta = dtArcLetter / _self.options.radius,
					// distance from the middle point of the semi arc's chord to the center of the circle.
					// this is going to be the place where the letter will be positioned.
					h = _self.options.radius * (Math.cos(beta / 2)),
					// angle formed by the x-axis and the left most point of the chord.
					alpha = Math.acos((_self.dtWord / 2 - iteratorX) / _self.options.radius),
					// angle formed by the x-axis and the right most point of the chord.
					theta = alpha + beta / 2,
					// distances of the sides of the triangle formed by h and the orthogonal to the x-axis.
					x = Math.cos(theta) * h,
					y = Math.sin(theta) * h,
					// the value for the coordinate x of the middle point of the chord.
					xpos = iteratorX + Math.abs(_self.dtWord / 2 - x - iteratorX),
					// finally, calculate how much to translate each letter, given its center point.
					// also calculate the angle to rotate the letter accordingly.
					xval = 0 | xpos - $letter.data('center'),
					yval = 0 | _self.options.radius - y,
					angle = (_self.options.rotate) ? 0 | -Math.asin(x / _self.options.radius) * (180 / Math.PI) : 0;

				// the iteratorX will be positioned on the second point of each semi arc
				iteratorX = 2 * xpos - iteratorX;

				// save these values
				$letter.data({
					x: xval,
					y: (_self.options.dir === 1) ? yval : -yval,
					a: (_self.options.dir === 1) ? angle : -angle
				});

			});

		},
		_rotateWord: function (animation) {

			if (!this.$el.data('arctext')) return false;

			var _self = this;

			this.$letters.each(function (i) {

				var $letter = $(this),
					transformation = (_self.options.radius === -1) ? 'none' : 'translateX(' + $letter.data('x') + 'px) translateY(' + $letter.data('y') + 'px) rotate(' + $letter.data('a') + 'deg)',
					transition = (animation) ? 'all ' + (animation.speed || 0) + 'ms ' + (animation.easing || 'linear') : 'none';

				$letter.css({
					'-webkit-transition': transition,
					'-moz-transition': transition,
					'-o-transition': transition,
					'-ms-transition': transition,
					'transition': transition
				})
				.css({
					'-webkit-transform': transformation,
					'-moz-transform': transformation,
					'-o-transform': transformation,
					'-ms-transform': transformation,
					'transform': transformation
				});

			});

		},
		_loadEvents: function () {

			if (this.options.fitText) {

				var _self = this;

				$(window).on('resize.arctext', function () {

					_self._calc();

					// apply transformation.
					_self._rotateWord();

				});

			}

		},
		set: function (opts) {

			if (!opts.radius &&
				!opts.dir &&
				opts.rotate === 'undefined') {
				return false;
			}

			this.options.radius = opts.radius || this.options.radius;
			this.options.dir = opts.dir || this.options.dir;

			if (opts.rotate !== undefined) {
				this.options.rotate = opts.rotate;
			}

			this._calc();

			this._rotateWord(opts.animation);

		},
		destroy: function () {

			this.options.radius = -1;
			this._rotateWord();
			this.$letters.removeData('x y a center');
			this.$el.removeData('arctext');
			$(window).off('.arctext');

		}
	};

	var logError = function (message) {
		if (this.console) {
			console.error(message);
		}
	};

	$.fn.arctext = function (options) {

		if (typeof options === 'string') {

			var args = Array.prototype.slice.call(arguments, 1);

			this.each(function () {

				var instance = $.data(this, 'arctext');

				if (!instance) {
					logError("cannot call methods on arctext prior to initialization; " +
					"attempted to call method '" + options + "'");
					return;
				}

				if (!$.isFunction(instance[options]) || options.charAt(0) === "_") {
					logError("no such method '" + options + "' for arctext instance");
					return;
				}

				instance[options].apply(instance, args);

			});

		}
		else {

			this.each(function () {

				var instance = $.data(this, 'arctext');
				if (!instance) {
					$.data(this, 'arctext', new $.Arctext(options, this));
				}
			});

		}

		return this;

	};

})(jQuery);

/*
 * Lazy Load - jQuery plugin for lazy loading images
 *
 * Copyright (c) 2007-2013 Mika Tuupola
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Project home:
 *   http://www.appelsiini.net/projects/lazyload
 *
 * Version:  1.8.4
 *
 */
(function(a,b,c,d){var e=a(b);a.fn.lazyload=function(c){function i(){var b=0;f.each(function(){var c=a(this);if(h.skip_invisible&&!c.is(":visible"))return;if(!a.abovethetop(this,h)&&!a.leftofbegin(this,h))if(!a.belowthefold(this,h)&&!a.rightoffold(this,h))c.trigger("appear"),b=0;else if(++b>h.failure_limit)return!1})}var f=this,g,h={threshold:0,failure_limit:0,event:"scroll",effect:"show",container:b,data_attribute:"original",skip_invisible:!0,appear:null,load:null};return c&&(d!==c.failurelimit&&(c.failure_limit=c.failurelimit,delete c.failurelimit),d!==c.effectspeed&&(c.effect_speed=c.effectspeed,delete c.effectspeed),a.extend(h,c)),g=h.container===d||h.container===b?e:a(h.container),0===h.event.indexOf("scroll")&&g.bind(h.event,function(a){return i()}),this.each(function(){var b=this,c=a(b);b.loaded=!1,c.one("appear",function(){if(!this.loaded){if(h.appear){var d=f.length;h.appear.call(b,d,h)}a("<img />").bind("load",function(){c.hide().attr("src",c.data(h.data_attribute))[h.effect](h.effect_speed),b.loaded=!0;var d=a.grep(f,function(a){return!a.loaded});f=a(d);if(h.load){var e=f.length;h.load.call(b,e,h)}}).attr("src",c.data(h.data_attribute))}}),0!==h.event.indexOf("scroll")&&c.bind(h.event,function(a){b.loaded||c.trigger("appear")})}),e.bind("resize",function(a){i()}),/iphone|ipod|ipad.*os 5/gi.test(navigator.appVersion)&&e.bind("pageshow",function(b){b.originalEvent.persisted&&f.each(function(){a(this).trigger("appear")})}),a(b).load(function(){i()}),this},a.belowthefold=function(c,f){var g;return f.container===d||f.container===b?g=e.height()+e.scrollTop():g=a(f.container).offset().top+a(f.container).height(),g<=a(c).offset().top-f.threshold},a.rightoffold=function(c,f){var g;return f.container===d||f.container===b?g=e.width()+e.scrollLeft():g=a(f.container).offset().left+a(f.container).width(),g<=a(c).offset().left-f.threshold},a.abovethetop=function(c,f){var g;return f.container===d||f.container===b?g=e.scrollTop():g=a(f.container).offset().top,g>=a(c).offset().top+f.threshold+a(c).height()},a.leftofbegin=function(c,f){var g;return f.container===d||f.container===b?g=e.scrollLeft():g=a(f.container).offset().left,g>=a(c).offset().left+f.threshold+a(c).width()},a.inviewport=function(b,c){return!a.rightoffold(b,c)&&!a.leftofbegin(b,c)&&!a.belowthefold(b,c)&&!a.abovethetop(b,c)},a.extend(a.expr[":"],{"below-the-fold":function(b){return a.belowthefold(b,{threshold:0})},"above-the-top":function(b){return!a.belowthefold(b,{threshold:0})},"right-of-screen":function(b){return a.rightoffold(b,{threshold:0})},"left-of-screen":function(b){return!a.rightoffold(b,{threshold:0})},"in-viewport":function(b){return a.inviewport(b,{threshold:0})},"above-the-fold":function(b){return!a.belowthefold(b,{threshold:0})},"right-of-fold":function(b){return a.rightoffold(b,{threshold:0})},"left-of-fold":function(b){return!a.rightoffold(b,{threshold:0})}})})(jQuery,window,document)




/*! matchMedia() polyfill - Test a CSS media type/query in JS. Authors & copyright (c) 2012: Scott Jehl, Paul Irish, Nicholas Zakas. Dual MIT/BSD license */
/*! NOTE: If you're already including a window.matchMedia polyfill via Modernizr or otherwise, you don't need this part */
window.matchMedia = window.matchMedia || function (a) { "use strict"; var c, d = a.documentElement, e = d.firstElementChild || d.firstChild, f = a.createElement("body"), g = a.createElement("div"); return g.id = "mq-test-1", g.style.cssText = "position:absolute;top:-100em", f.style.background = "none", f.appendChild(g), function (a) { return g.innerHTML = '&shy;<style media="' + a + '"> #mq-test-1 { width: 42px; }</style>', d.insertBefore(f, e), c = 42 === g.offsetWidth, d.removeChild(f), { matches: c, media: a } } }(document);

/*! Respond.js v1.1.0: min/max-width media query polyfill. (c) Scott Jehl. MIT/GPLv2 Lic. j.mp/respondjs  */
(function (a) { "use strict"; function x() { u(!0) } var b = {}; if (a.respond = b, b.update = function () { }, b.mediaQueriesSupported = a.matchMedia && a.matchMedia("only all").matches, !b.mediaQueriesSupported) { var q, r, t, c = a.document, d = c.documentElement, e = [], f = [], g = [], h = {}, i = 30, j = c.getElementsByTagName("head")[0] || d, k = c.getElementsByTagName("base")[0], l = j.getElementsByTagName("link"), m = [], n = function () { for (var b = 0; l.length > b; b++) { var c = l[b], d = c.href, e = c.media, f = c.rel && "stylesheet" === c.rel.toLowerCase(); d && f && !h[d] && (c.styleSheet && c.styleSheet.rawCssText ? (p(c.styleSheet.rawCssText, d, e), h[d] = !0) : (!/^([a-zA-Z:]*\/\/)/.test(d) && !k || d.replace(RegExp.$1, "").split("/")[0] === a.location.host) && m.push({ href: d, media: e })) } o() }, o = function () { if (m.length) { var b = m.shift(); v(b.href, function (c) { p(c, b.href, b.media), h[b.href] = !0, a.setTimeout(function () { o() }, 0) }) } }, p = function (a, b, c) { var d = a.match(/@media[^\{]+\{([^\{\}]*\{[^\}\{]*\})+/gi), g = d && d.length || 0; b = b.substring(0, b.lastIndexOf("/")); var h = function (a) { return a.replace(/(url\()['"]?([^\/\)'"][^:\)'"]+)['"]?(\))/g, "$1" + b + "$2$3") }, i = !g && c; b.length && (b += "/"), i && (g = 1); for (var j = 0; g > j; j++) { var k, l, m, n; i ? (k = c, f.push(h(a))) : (k = d[j].match(/@media *([^\{]+)\{([\S\s]+?)$/) && RegExp.$1, f.push(RegExp.$2 && h(RegExp.$2))), m = k.split(","), n = m.length; for (var o = 0; n > o; o++) l = m[o], e.push({ media: l.split("(")[0].match(/(only\s+)?([a-zA-Z]+)\s?/) && RegExp.$2 || "all", rules: f.length - 1, hasquery: l.indexOf("(") > -1, minw: l.match(/\(\s*min\-width\s*:\s*(\s*[0-9\.]+)(px|em)\s*\)/) && parseFloat(RegExp.$1) + (RegExp.$2 || ""), maxw: l.match(/\(\s*max\-width\s*:\s*(\s*[0-9\.]+)(px|em)\s*\)/) && parseFloat(RegExp.$1) + (RegExp.$2 || "") }) } u() }, s = function () { var a, b = c.createElement("div"), e = c.body, f = !1; return b.style.cssText = "position:absolute;font-size:1em;width:1em", e || (e = f = c.createElement("body"), e.style.background = "none"), e.appendChild(b), d.insertBefore(e, d.firstChild), a = b.offsetWidth, f ? d.removeChild(e) : e.removeChild(b), a = t = parseFloat(a) }, u = function (b) { var h = "clientWidth", k = d[h], m = "CSS1Compat" === c.compatMode && k || c.body[h] || k, n = {}, o = l[l.length - 1], p = (new Date).getTime(); if (b && q && i > p - q) return a.clearTimeout(r), r = a.setTimeout(u, i), void 0; q = p; for (var v in e) if (e.hasOwnProperty(v)) { var w = e[v], x = w.minw, y = w.maxw, z = null === x, A = null === y, B = "em"; x && (x = parseFloat(x) * (x.indexOf(B) > -1 ? t || s() : 1)), y && (y = parseFloat(y) * (y.indexOf(B) > -1 ? t || s() : 1)), w.hasquery && (z && A || !(z || m >= x) || !(A || y >= m)) || (n[w.media] || (n[w.media] = []), n[w.media].push(f[w.rules])) } for (var C in g) g.hasOwnProperty(C) && g[C] && g[C].parentNode === j && j.removeChild(g[C]); for (var D in n) if (n.hasOwnProperty(D)) { var E = c.createElement("style"), F = n[D].join("\n"); E.type = "text/css", E.media = D, j.insertBefore(E, o.nextSibling), E.styleSheet ? E.styleSheet.cssText = F : E.appendChild(c.createTextNode(F)), g.push(E) } }, v = function (a, b) { var c = w(); c && (c.open("GET", a, !0), c.onreadystatechange = function () { 4 !== c.readyState || 200 !== c.status && 304 !== c.status || b(c.responseText) }, 4 !== c.readyState && c.send(null)) }, w = function () { var b = !1; try { b = new a.XMLHttpRequest } catch (c) { b = new a.ActiveXObject("Microsoft.XMLHTTP") } return function () { return b } }(); n(), b.update = n, a.addEventListener ? a.addEventListener("resize", x, !1) : a.attachEvent && a.attachEvent("onresize", x) } })(this);

Modernizr.addTest('backgroundclip', function () {

	var div = document.createElement('div');

	if ('backgroundClip' in div.style)
		return true;

	'Webkit Moz O ms Khtml'.replace(/([A-Za-z]*)/g, function (val) {
		if (val + 'BackgroundClip' in div.style) return true;
	});

});

// smart resize
(function($,sr){

  // debouncing function from John Hann
  // http://unscriptable.com/index.php/2009/03/20/debouncing-javascript-methods/
  var debounce = function (func, threshold, execAsap) {
      var timeout;

      return function debounced () {
          var obj = this, args = arguments;
          function delayed () {
              if (!execAsap)
                  func.apply(obj, args);
              timeout = null;
          };

          if (timeout)
              clearTimeout(timeout);
          else if (execAsap)
              func.apply(obj, args);

          timeout = setTimeout(delayed, threshold || 100);
      };
  }
  // smartresize 
  jQuery.fn[sr] = function(fn){  return fn ? this.bind('resize', debounce(fn)) : this.trigger(sr); };

})(jQuery,'smartresize');