var fencing = {
    testMode: false,
    testFence: '',
    locationNames: []
  };

//=================================
// FENCING DATA
//=================================
fencing.locationData = {
  chicago: {
    coords: [
      new google.maps.LatLng(42.49539, -88.659668),
      new google.maps.LatLng(42.49539, -87.010345),
      new google.maps.LatLng(41.368564, -87.010345),
      new google.maps.LatLng(41.368564, -88.659668)
    ],
    copy: 'Hop off the Loop and into an opportunity to make a difference in the Chicago area. You have the opportunity to use your strengths to help you and your community develop and grow in ways that are meaningful and rewarding. If that interests you, we invite you to learn more and see where it leads you.',
    brandedCopy: 'Hop off the Loop and into an opportunity to make a difference in the Chicago area. As a Chick-fil-A<sup>&#174;</sup> Operator, you have the opportunity to use your strengths to help you and your community develop and grow in ways that are meaningful and rewarding. If that interests you, we invite you to learn more and see where it leads you.'
  },
  seattle: {
    coords: [
      new google.maps.LatLng(47.638560, -122.415848),
      new google.maps.LatLng(47.638560, -122.178955),
      new google.maps.LatLng(47.542237, -122.178955),
      new google.maps.LatLng(47.542237, -122.415848)
    ],
    copy: 'Are you interested in connecting with locals to make a difference in the Seattle area? You have the opportunity to use your strengths to help you and your community develop and grow in ways that are meaningful and rewarding. If that interests you, we invite you to learn more and see where it leads you.',
    brandedCopy: 'Are you interested in connecting with locals to make a difference in the Seattle area? As a Chick-fil-A<sup>&#174;</sup> Operator, you have the opportunity to use your strengths to help you and your community develop and grow in ways that are meaningful and rewarding. If that interests you, we invite you to learn more and see where it leads you.'
  },
  portland: {
    coords: [
      new google.maps.LatLng(45.666422, -122.935246),
      new google.maps.LatLng(45.666422, -122.453042),
      new google.maps.LatLng(45.378215, -122.453042),
      new google.maps.LatLng(45.378215, -122.935246)
    ],
    copy: 'Looking to positively impact the culture and community of the Portland area? You have the opportunity to use your strengths to help you and your community develop and grow in ways that are meaningful and rewarding. If that interests you, we invite you to learn more and see where it leads you.',
    brandedCopy: 'Looking to positively impact the culture and community of the Portland area? As a Chick-fil-A Operator, you have the opportunity to use your strengths to help you and your community develop and grow in ways that are meaningful and rewarding. If that interests you, we invite you to learn more and see where it leads you.'
  },
  connecticut: {
    coords: [
      new google.maps.LatLng(42.023557, -71.800651),
      new google.maps.LatLng(41.240803, -71.807321),
      new google.maps.LatLng(40.945056, -73.603128),
      new google.maps.LatLng(42.049613, -73.487307)
    ],
    copy: 'There’s plenty of room for you to make a big impact in your corner of Connecticut. You have the opportunity to use your strengths to help you and your community develop and grow in ways that are meaningful and rewarding. If that interests you, we invite you to learn more and see where it leads you.',
    brandedCopy: 'There’s plenty of room for you to make a big impact in your corner of Connecticut. As a Chick-fil-A Operator, you have the opportunity to use your strengths to help you and your community develop and grow in ways that are meaningful and rewarding. If that interests you, we invite you to learn more and see where it leads you.'
  },
  boston: {
    coords: [
      new google.maps.LatLng(42.745178, -73.266626),
      new google.maps.LatLng(42.677270, -69.882100),
      new google.maps.LatLng(42.677270, -69.882100),
      new google.maps.LatLng(41.352374, -71.019330),
      new google.maps.LatLng(42.020880, -71.356309),
      new google.maps.LatLng(42.049678, -73.496869),
      new google.maps.LatLng(42.049678, -73.496869),
    ],
    copy: 'Now is the time to make a positive impact in your corner of Massachusetts. You have the opportunity to use your strengths to help you and your community develop and grow in ways that are meaningful and rewarding. If that interests you, we invite you to learn more and see where it leads you.',
    brandedCopy: 'Now is the time to make a positive impact in your corner of Massachusetts. As a Chick-fil-A Operator, you have the opportunity to use your strengths to help you and your community develop and grow in ways that are meaningful and rewarding. If that interests you, we invite you to learn more and see where it leads you.'
  },
};

//=================================
// FENCING METHODS
//=================================
fencing.init = function() {
  //check location and branding
  var locationName,
      branded;

  fencing.locationNames = Object.keys(fencing.locationData);
  locationName = fencing.getLocationName();

  if (locationName) {
    location = fencing.locationData[locationName];
    branded = window.location.search.indexOf("branded") > -1;
    if (branded) {
      // branded banner, show copy and logo
      els.dynamicCopy.html(location.brandedCopy);
      $("li.middle img").fadeIn('slow');
    } else {
      // non-branded banner, show default copy
      els.dynamicCopy.html(location.copy);
    }
  } else {
    //make the request for the users location, if that fails do nothing, show default text
    if (navigator && navigator.geolocation) {
      // make the request for the user's position, with a success callback
      navigator.geolocation.getCurrentPosition(this.processLocation);
    }
  }

  if (fencing.testMode) {
    if (fencing.testFence) {
      fencing.test(fencing.testFence);
    } else {
      fencing.test();
    }
  }
};

fencing.getLocationName = function() {
  var locationName,
      i = 0;

  for (i; i < fencing.locationNames.length; i++) {
    locationName = fencing.locationNames[i];
    if (window.location.search.indexOf(locationName) > -1) {
      return location;
      break;
    }
  }
};

fencing.processLocation = function(position){
    var locationFound = false,
        locationName,
        location,
        i = 0;

    for (i; i < fencing.locationNames.length; i++) {
      locationName = fencing.locationNames[i];
      location = fencing.locationData[locationName];

      if (fencing.checkLocation(locationName, position.latitude, position.longitude)) {
        locationFound = true;
        els.dynamicCopy.html(location.copy);
        break;
      }
    }

    return locationFound;
};

fencing.checkLocation = function (locationName, lat, lng) {
  var boundaries = new google.maps.Polygon({
      paths: fencing.locationData[locationName].coords
  });

  return google.maps.geometry.poly.containsLocation(new google.maps.LatLng(lat, lng), boundaries);
};

//=================================
// FENCE TESTER METHODS
//=================================
fencing.getTestCoords = function(locationName) {
  function getMinMax(type, values) {
    var temp = values.slice();

    function looper(type, temp) {
      var val;
      if(temp.length == 0) {
        return NaN;
      } else if(temp.length == 1) {
        val = temp.pop();
        if ( typeof val == "number" ) {
          return val;
        } else {
          return NaN;
        }
      } else {
        val = temp.pop();
        return Math[type](val, looper(type, temp))
      }
    }

    return looper(type, temp);
  }

  function getRandomNumber(greater, lesser) {
    return Math.random() * (greater - lesser) + lesser;
  }

  function getRandomCoords(perimeter) {
    var latitudes = [],
        longitudes = [],
        lat = {},
        lng = {},
        i = 0;

    for (i; i < perimeter.length; i++) {
      latitudes.push(perimeter[i].G);
      longitudes.push(perimeter[i].K);
    }

    lat.min = getMinMax('min', latitudes);
    lat.max = getMinMax('max', latitudes);
    lng.min = getMinMax('min', longitudes);
    lng.max = getMinMax('max', longitudes);

    return {
      latitude: getRandomNumber(lat.max, lat.min),
      longitude: getRandomNumber(lng.max, lng.min),
    };
  }

  return getRandomCoords(fencing.locationData[locationName].coords);
};

fencing.test = function(locationName) {
  var generatedLocation,
      locationFound,
      $indicator = $('<div id="current-generated-location">');

  $indicator.css({
    position: 'fixed',
    bottom: 0,
    left: 0,
    background: 'black',
    color: 'white',
    fontSize: '20px',
    padding: '10px 20px',
    zIndex: '9999'
  });

  $('body').append($indicator);

  if (!locationName) {
    var randomIndex = Math.floor(Math.random() * fencing.locationNames.length - 1) + 1;
    locationName = fencing.locationNames[randomIndex];
  }

  console.log('Testing generated coordinates in ' + locationName);

  generatedLocation = fencing.getTestCoords(locationName);
  locationFound = fencing.processLocation(generatedLocation);

  if (locationFound) {
    console.log('Test passed!');
    $indicator.text('Generated location: ' + locationName);
  } else {
    console.log('Test failed...');
    $indicator.text('Error. Try again.');
  }
};
