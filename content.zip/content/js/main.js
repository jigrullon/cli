"use strict";
var debug = window.location.search.indexOf("debug")>-1,
    scrollSway = null,
    ints = 0;

var els = {
	'toTopLink': $('.top'),
	'sections': $(".adjust"),
    'dynamicCopy': $('#dynamic-copy')
};

var currentSectionId="";
var lastSectionId="none";
var sectionTracked = [];

// Added in array support for IE
if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function (searchElement /*, fromIndex */ ) {
        "use strict";
        if (this == null) {
            throw new TypeError();
        }
        var t = Object(this);
        var len = t.length >>> 0;
        if (len === 0) {
            return -1;
        }
        var n = 0;
        if (arguments.length > 0) {
            n = Number(arguments[1]);
            if (n != n) { // shortcut for verifying if it's NaN
                n = 0;
            } else if (n != 0 && n != Infinity && n != -Infinity) {
                n = (n > 0 || -1) * Math.floor(Math.abs(n));
            }
        }
        if (n >= len) {
            return -1;
        }
        var k = n >= 0 ? n : Math.max(len - Math.abs(n), 0);
        for (; k < len; k++) {
            if (k in t && t[k] === searchElement) {
                return k;
            }
        }
        return -1;
    }
}

// Object.keys polyfill
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/keys
if (!Object.keys) {
  Object.keys = (function() {
    'use strict';
    var hasOwnProperty = Object.prototype.hasOwnProperty,
        hasDontEnumBug = !({ toString: null }).propertyIsEnumerable('toString'),
        dontEnums = [
          'toString',
          'toLocaleString',
          'valueOf',
          'hasOwnProperty',
          'isPrototypeOf',
          'propertyIsEnumerable',
          'constructor'
        ],
        dontEnumsLength = dontEnums.length;

    return function(obj) {
      if (typeof obj !== 'object' && (typeof obj !== 'function' || obj === null)) {
        throw new TypeError('Object.keys called on non-object');
      }

      var result = [], prop, i;

      for (prop in obj) {
        if (hasOwnProperty.call(obj, prop)) {
          result.push(prop);
        }
      }

      if (hasDontEnumBug) {
        for (i = 0; i < dontEnumsLength; i++) {
          if (hasOwnProperty.call(obj, dontEnums[i])) {
            result.push(dontEnums[i]);
          }
        }
      }
      return result;
    };
  }());
}

var site = {
	init: function() {
		trackPixel(); // track initial load
		this.positionLink(els.toTopLink);
		var heights = this.getSectionHeights();
		if ($(window).width() > 991) {
			this.maximizeSectionHeights();
		}
		$(window).smartresize(function() {
			site.adjustSectionHeights(heights);
			site.positionLink(els.toTopLink);
		});
		fit.init();

		// reset the Fit tool when any top nav item is clicked.
		$('#main-nav a').click(function(evt){
			evt.preventDefault();
            var GATitle = $(this).data('ga-title');
			fit.init();

            ga('send', 'event', 'Navigation', 'Link', GATitle);
		});

        fencing.init();
	},
	// the following 4 functions set each section height to the height of
	// the browser, client wants each section to fit in the window w/o
	// others showing, will revert to original min-height setting when
	// browser width is less than 1024px
	getSectionHeights: function() {
		var heights = [];
		$.each(els.sections, function() {
			var el = $(this);
			heights.push(el.css("min-height"));
		});
		return heights;
	},
	adjustSectionHeights: function(heights) {
		if ($(window).width() > 1024) {
			this.maximizeSectionHeights();
		} else {
			this.minimizeSectionHeights(heights);
		}
	},
	maximizeSectionHeights: function() {
		$.each(els.sections, function() {
			var el = $(this);
			el.css("min-height", $(window).height() + "px");
		});
	},
	minimizeSectionHeights: function(heights) {
		$.each(els.sections, function(i) {
			var el = $(this);
			el.css("min-height", heights[i]);
		});
	},
	//
	positionLink: function(link) {
		// link goes to right if window > 421px, centered otherwise
		var position = $(window).width() < 421 ? $(window).width() / 2 - (link.width() / 2) : $(window).width() / 5;
		// link.css("left", position + "px");
	},
	swapOutBackground: function(index) {
        //var currentId = ('.passion_slider .graphic_nav .active').attr('id');
        var id = $('.graphic_nav li').eq(index).addClass('active').attr('id');
        if (id) {
	        $( '.passion_slider .background img' ).attr( 'src', 'img/passions/backgrounds/'+id+'.jpg');
	    }
	}
};

// click something, append second slide, animate up, remove first slide
var fit = {
	els: {
		"container": $("#fitContainer"),
		"checkboxes": $("#q3 a"),
	},
	slides: {
		"first": "<div class='slide first'><h3>Is being a Chick-fil-A<sup>&#174;</sup> operator</h3><h1>right for you?</h1>" +
			"<h4>Here's a way to find out.</h4><p>Answer these questions honestly and you'll<br />" +
			"learn more about the opportunity and yourself.</p>" +
			"<div class='icon'>c</div><a href='#q1' class='next-question getstarted'>Get Started.</a></div>",

		"q1": "<div id='q1' class='slide'><h3>Are you seeking a great</h3><h1>investment<br />opportunity?</h1>" +
			"<a href='#yes1'>yes</a><a href='#no1'>no</a><div class='lines'></div><div id='dollars'>" +
			"<span>j</span><span class='large'>j</span><span>j</span></div></div>",
		"yes1": "<div id='yes1' class='slide'><div class='lines'></div><div class='spacer'></div><p>Perfect. That is, if you're planning on " +
			"<span class='red uppercase'>investing your own time and energy. </span>" +
			"This isn't a round-out-your-portfolio kind of investment. We want 100% of your best efforts.</p>" +
			"<a href='#q3' class='capitalize next next-question'>Continue to Next Question</a></div>",
		"no1": "<div id='no1' class='slide'><p>Right, this is about <span class='red uppercase'>investing in your future, </span>" +
			"not pouring in money, sitting back and expecting a return. We want you to roll up your sleeves and jump in." +
			"<span class='white icon'>p</span></p>" +
			"<a href='#q3' class='capitalize next next-question'>Continue to Next Question</a><div class='lines'></div></div>",

		"q3": "<div id='q3' class='slide'><div class='spacer'></div><div class='icon yellow'><span class='burger'>h</span><span class='fries'>n</span>" +
			"<span class='soda'>q</span><span class='cone'>w</span></div>" +
			"<h3>Do you think</h3><h1 class='red'>all fast-food</h1><h3>restaurants are the same?</h3>" +
			"<a href='#yes3'><h1 class='yellow'>yes</h1></a><a href='#no3'><h1 class='yellow'>no</h1></a></div>",
		"yes3": "<div id='yes3' class='slide'><div class='images'><img src='img/fit/img_2.jpg' alt=''><img src='img/fit/img_3.jpg' alt=''>" +
			"<img src='img/fit/img_4.jpg' alt=''></div><p>We get it. The stereotypes of fast-food are well established. " +
			"Only we truly have a different philosophy. And we make sure it comes through. Our Franchised Restaurants do a lot more " +
			"than serve food fast and make numbers.  Pay us a visit and see.</p><a href='#q4' class='capitalize next next-question'>Continue to Next Question</a></div>",
		"no3": "<div id='no3' class='slide'><div class='images'><img src='img/fit/img_2.jpg' alt=''><img src='img/fit/img_3.jpg' alt=''>" +
			"<img src='img/fit/img_4.jpg' alt=''></div><p>Have you perhaps dined at a Chick-fil-A<sup>&#174;</sup> " +
			"Restaurant? Then you know there's something special going on here. The attention to customers is as much alive " +
			"today as it was when our founder opened his first restaurant more than 60 years ago.</p>" +
			"<a href='#q4' class='capitalize next next-question'>Continue to Next Question</a></div>",

		"q4": "<div id='q4' class='slide'><h3>Are you</h3><h1>perfectly<br />happy</h1><h3>doing what you're doing?</h3>" +
			"<div id='thumbs'><a href='#yes4' data-value='yes'></a><div class='yes lines horizontal'></div><span class='icon yellow'>r</span><a href='#no4' data-value='no'></a>" +
			"<div class='no lines horizontal'></div><div class='lines vertical'></div></div>" +
			"</div>",
		"yes4": "<div id='yes4' class='slide'><div class='spacer'></div><div class='lines'></div><div class='banner2'><h5 class='uppercase red'>Congratulations</h5></div><p><span class='red uppercase'>" +
			"Loving what you do is important.</span><br />We still invite you to get to know us a little better. Many people who were happy in their " +
			"prior careers find our opportunity too good to pass up.</p><a href='#q7' class='capitalize next next-question'>Continue to Next Question</a></div>",
		"no4": "<div id='no4' class='slide'><div class='spacer'></div><div class='lines'></div><p>If you've been looking for something that<br /><span class='red uppercase'>satisfies the</span></p>" +
			"<div class='banner2'><h5 class='uppercase red'>entrepreneur</h5></div><p><span class='red uppercase'>in you</span><br />while supporting you every " +
			"step of the way with a proven system of success, we may be exactly what <br />you're looking for.</p>" +
			"<a href='#q7' class='capitalize next next-question'>Continue to Next Question</a></div>",

		"q7": "<div id='q7' class='slide'><h3>When you've got a business</h3><h1>to run, ______.</h1><a href='#sevenA'><h2 class='red'>A. Do it yourself.</h2></a>" +
			"<a href='#sevenB'><h2 class='red'>B. Hire good people to run it.</h2></a></div>",
		"sevenA": "<div id='sevenA' class='slide'><div class='icon blueGreen'><span>i</span><span>i</span></div>" +
			"<p><span class='red uppercase'>A. &#8208;&#8208; That's the spirit.</span><br />We're looking for people who are hands-on and enjoy being in " +
			"the middle of a kitchen just as much as being in the middle of the restaurant chatting up guests.</p>" +
			"<a href='#q8' class='capitalize next next-question'>Continue to Next Question</a></div>",
		"sevenB": "<div id='sevenB' class='slide'><div class='icon blueGreen'><span>i</span><span>i</span></div>" +
			"<p><span class='red uppercase'>B. &#8208;&#8208; You can't do it all, right? Right.</span><br />We want you " +
			"to be able to build a team that gives you the confidence to go off and take a hands-on approach to building the business.</p>" +
			"<a href='#q8' class='capitalize next next-question'>Continue to Next Question</a></div>",

		"q8": "<div id='q8' class='slide'><h3>I'm more comfortable</h3><h1>__________.</h1><a href='#eightA'><h1>A</h1><h1>Crunching<br />" +
			"Numbers</h1></a><a href='#eightB'><h1>B</h1><h1>Shaking<br />Hands</h1></a></div>",
		"eightA": "<div id='eightA' class='slide'><div class='icon yellow'><span>u</span><span>t</span><span>f</span><span class='red'>+</span><span>x</span></div>" +
			"<p><span class='red uppercase'>A. &#8208;&#8208; Nothing wrong with that.</span><br />" +
			"It's an important part of building a business. Just know that we also value people who enjoy people and tallying up relationships.</p>" +
			"<a href='#q9' class='capitalize next next-question'>Continue to Next Question</a></div>",
		"eightB": "<div id='eightB' class='slide'><div class='icon yellow'><span>x</span></div><p>B. &#8208;&#8208; People person, huh? That's great.<br />" +
			"From building and maintaining your staff to making guests feel special, being a<br /><span class='red uppercase'>franchised operator is all about relationships.</span>" +
			"<br />But don't forget there's a business side to <br />the equation as well.<a href='#q9' class='capitalize next next-question'>Continue to Next Question</a></div>",

		"q9": "<div id='q9' class='slide'><h3>I want a career opportunity<br />that allows me to</h3><h1>_________.</h1>" +
			"<div><a href='#nineA'><h1><span>A</span>Launch a<br />new business</h1></a><a href='#nineB'><h1><span>B</span>Follow a<br />proven system</h1></a></div></div>",
		"nineA": "<div id='nineA' class='slide'><div class='images'><img src='img/fit/img_7.png' alt=''><img src='img/fit/img_8.jpg' alt=''><img src='img/fit/img_9.png' alt=''></div>" +
			"<p><span class='red uppercase'>A. &#8208;&#8208; And you will.</span><br />You'll be the point person that introduces the Chick-fil-A<sup>&#174;</sup> brand to the" +
			" community and keeps it top-of-mind for years to come. But you won't do it alone. You'll be backed by the training and expertise" +
			" you need to be successful throughout your journey</p><a href='#q10' class='capitalize next next-question'>Continue to Next Question</a></div>",
		"nineB": "<div id='nineB' class='slide'><div class='images'><img src='img/fit/img_7.png' alt=''><img src='img/fit/img_8.jpg' alt=''><img src='img/fit/img_9.png' alt=''></div>" +
			"<p><span class='red uppercase'>B. &#8208;&#8208; And you will.</span><br />The Chick-fil-A<sup>&#174;</sup> system has been successful for decades. " +
			"But the beauty is that our system allows you the flexibility to establish your own Franchised Restaurant business.</p><a href='#q10' class='capitalize next next-question'>Continue to Next Question</a></div>",

        "q10": "<div id='q10' class='slide'><h1>You Answered, <br /> You Learned.</h1><p>" +
            "And hopefully have a better understanding of what this opportunity has to offer. If you liked the answers you received, we invite you to keep exploring the site as you continue down the path of finding out if being a Chick-fil-A<sup>&#174;</sup> Operator is right for you." +
            "</p><br /><p><a href='#first' class='next-question redo-quiz'>Want another look at these questions?<br/><strong>Click here to begin again.</strong></a></p></div>",
	},
	init: function() {
		this.els.container.empty().append(fit.slides.first);
		this.appendNext();

        this.els.container.on('click.next-question', 'a.next-question', function () {
            var $this = $(this);

            if ($this.hasClass('getstarted')) {
                ga('send', 'event', 'Quiz', 'Click', 'Start');
                return;
            }

            if ($this.hasClass('redo-quiz')) {
                ga('send', 'event', 'Quiz', 'Click', 'Redo Quiz');
                return;
            }

            ga('send', 'event', 'Quiz', 'Click', 'Next Question Arrow');
        });
	},
	appendNext: function() {
		this.els.container.find("a").click(function(e) {
			e.preventDefault();

            var $this = $(this),
                slide = fit.els.container.children().first(),
                next = $(this)[0]["hash"].slice(1),
                href = $this.attr('href');

            if ($this.hasClass('next-question') || $this.hasClass('redo-quiz') || $this.hasClass('getstarted')) {
                // do nothing
            } else {
                ga('send', 'event', 'Quiz', 'Click', href);
            }

			fit.els.container.append(fit.slides[next]);
			fit.showNext(slide);
		});
	},
	showNext: function(slide) {
		this.appendNext();
		this.els.container.animate({top: "-" + slide.height() + "px"}, 600, function() {
			slide.remove();
			$(this).css("top", "0px");
		});
	}
};

(function($, app, window) {

    var logoShowing = false,
        scrolling = false,

        $waypointSelector = $('#main .page-section'),
        $logo = $('.main-nav a.logo > img');


    app.showLogo = function () {
        if (logoShowing)
            return;

        $logo.fadeIn('slow');
        logoShowing = true;
    };

    // modified from http://css-tricks.com/snippets/javascript/get-url-variables/
    app.getQueryVariable = function (paramater) {
        var query = window.location.search.substring(1),
            vars;

        if (query.length == 0)
            return false;

        vars = query.split("&");

        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == paramater)
                return pair[1];
        }

        return false;
    };

    app.swapCopy = function (location) {
        var location = (typeof location === 'undefined') ? app.getQueryVariable('location') : location,
            $copy = null,
            availableLocations = ['chicago', 'seattle'];

        // Safety check
        if (typeof location == 'undefined')
            location = 'default';

        if ($.inArray(location, availableLocations) == -1)
            location = 'default';

        $copy = $('.copy-change[data-copy-type="' + location + '"]');

        $copy.show();
    };

    app.video = function(){
        $('.introVideo').on({
            mouseenter: function(){
                $('.skip').stop().fadeIn();
            },
            mouseleave: function(){
                $('.skip').stop().fadeOut();
            }
        });

        $('.skip').on('click', function(e){
            $('.introVideo').addClass('remove');
            setTimeout(function(){
                $('.introVideo iframe').attr('src', '');
                $('.wrapper').fadeIn();
                app.therest();
            }, 1000)

            e.preventDefault();
        })
    };


    app.sendFlexGARequest = function ($flex) {
        var $slide = $flex.find('.slide.flex-active-slide'),
            GATitle = $slide.data('ga-title'),
            GACategory = $flex.data('ga-category');

        ga('send', 'event', GACategory, 'Arrow', GATitle);
    };


    //loads the rest of the actions.
    app.therest = function(){

        /* Start the scroll timeout for more cta.
        **********************************************/
        app.scrollTimeout();

		window.setInterval(function(){
			sectionTracker();
		},3000);


        /* Plugin calls
        **********************************************/
        $(window).load(function () {

            $('.overview .flexslider').flexslider({
                animation: "slide",
				slideshow: false,
                after: function ($flex) {
                    var args = Array.prototype.slice.call(arguments);
                    app.sendFlexGARequest($flex);
                }
            });


            $('#personDetail').flexslider({
				slideshow: false,
                after: function ($flex) {
                    app.sendFlexGARequest($flex);
                }
			});

            $('.passion_slider .flexslider').flexslider({
                // controlNav: false,
                slideshow: false,
                animation: "slide",
                before: function(){
                    $('.graphic_nav').find('.active').removeClass('active');
                },
                after: function($flex){
                    site.swapOutBackground($flex.currentSlide);
                    app.sendFlexGARequest($flex);
                }
            });

            $('.faqs .flexslider').flexslider({
                controlNav: false,
                slideshow: false,
                animation: 'slide',
                after: function ($flex) {
                    app.sendFlexGARequest($flex);
                }
            });

        });
        //lazy loader
        $('.lazy').lazyload({
            effect: 'fadeIn'
        });


        /* all scrolling actions
        *************************************/
        // Cache selectors
        var topMenu = $("#main-nav"),
            topMenuHeight = topMenu.outerHeight()+15,
            menuItems = topMenu.find("a"),
            $floatingInterestButton = $('.floatinginterest'),
            // Anchors corresponding to menu items
            scrollItems = menuItems.map(function(){
              var item = $($(this).attr("href"));
              if (item.length) { return item; }
            });

        // initial floating interest button text to be toggled
        var floatinginterestButtonText = $floatingInterestButton.text();

			// Fix for mobile navigation
			if(topMenuHeight>100){topMenuHeight=0;}

        $(window).on('scroll', function(){
          var fromTop = $(this).scrollTop()+topMenuHeight;

          var cur = scrollItems.map(function(){
             if ($(this).offset().top < fromTop)
               return this;
          });

          cur = cur[cur.length-1];
          var id = cur && cur.length ? cur[0].id : "";


            app.showLogo();

			currentSectionId = id;

			menuItems
             .parent().removeClass("active")
             .end().filter("[href=#"+id+"]").parent().addClass("active");


            // if(id === 'faqs'){
            //     $('.floatinginterest').fadeOut('fast');
            //     if(window.scrollSway){
            //         window.scrollSway = null;
            //     }
            //     $('.scrollmore').fadeOut();
            // }else{
            //     $('.floatinginterest').fadeIn('slow');
            // }



            /* Hides "Scroll to find out more"
            *********************************************/
            $('.scrollmore').fadeOut();
        });

        /* Click actions
        ****************************************/
        $('#main-nav').on('click', 'li a', function(e){
            var id = $(this).attr('href'),
                targetTop = ($(id).offset().top - topMenuHeight)+15,
                parent = $(this).parent();

            $('#main-nav').find('.active').removeClass('active');
            parent.addClass('active');

            app.amimateScroll(targetTop);

            e.preventDefault();
			trackBySection(id);
        });

        $('.menu').on('click', 'a', function(e){
            var id = $(this).attr('href'),
                targetTop = $(id).offset().top;

            app.amimateScroll(targetTop);

            e.preventDefault();

			trackBySection(id);
        });

        $('.top').on('click', function(e){
            ga('send', 'event', 'Top', 'Link', 'Back to Top');
            app.amimateScroll(0);
        });

		$('.floatinginterest, .interrupt__close').click(function(e){
			e.preventDefault();
			var $button = $(this),
        $body = $('body'),
        href = $button.attr('href');

      $body.toggleClass('is-interested');

      if ($body.hasClass('is-interested')) {
        trackPixel("ImInterestedButton");
		ga('send', 'pageview', { 'page': 'i-am-interested','title': "I'm Interested Popup"});
        ga('send', 'event', 'Floating Interest', 'Button', "I'm Interested");

        $('.floatinginterest').text('Maybe later');

        $(document).on('click.close-interrupt tap.close-interrupt touch.close-interrupt', function (e) {
          var $target = $(e.target);
          if ($target.closest('.interrupt__wrap').length == 0) {
            $body.removeClass('is-interested');
          }
        });
      } else {
        trackPixel("MaybeLater");
        ga('send', 'event', 'Floating Interest', 'Button', "Maybe later");
        $('.floatinginterest').text(floatinginterestButtonText);
        $(document).off('click.close-interrupt tap.close-interrupt touch.close-interrupt');
      }
		});

    $('.interrupt__cta').on('click', function (e) {
      e.preventDefault();
      var href = $(this).attr('href');

      trackPixel("LetsGetStarted");
      ga('send', 'pageview');
      ga('send', 'event', 'Floating Interest', 'Button', "Let's get started");
      setTimeout(function() { window.location = href }, 500);
    });

    // TODO remove this when done with development
    // $('.floatinginterest').trigger('click');

		$('.interest').click(function(e){
			e.preventDefault();
			var href = $(this).attr('href');
            trackPixel("ExpressInterestButton");
            console.log('ga fired');
            ga('send', 'event', 'Floating Interest', 'Button', "I'm Interested");
            ga('send', 'pageview', {'page': 'i-am-interested','title': "I'm Interested Popup"});
			setTimeout(function() {window.location = href}, 500);
		});


        $(".peeps").on('click', 'li', function (e) {
            var index = $(this).index(),
                anchor = $(this).find('a').attr('href'),
                top = $(anchor).offset().top - topMenu.height();

            $(this).parent().find('.active').removeClass('active');
            $(this).addClass('active');

            app.amimateScroll(top);

            setTimeout(function(){
                $('#personDetail').flexslider(index);
            }, 500)

            e.preventDefault();
        });


        $('.slider_nav').on('click', 'li', function(){
            var top = $('.passion_slider').offset().top;

            $(this).parent().find('.active').removeClass('active');
            $(this).addClass('active');

            app.amimateScroll(top);

            $('.passion_slider .flexslider').flexslider($(this).index());
        });

	    $('.graphic_nav').on('click', 'li', function(){
            var top = $('.passion_slider').offset().top;
            var currentId = (this.id);
            $( '.passion_slider .background img' ).attr( 'src', 'img/passions/backgrounds/'+currentId+'.jpg');

            $(this).parent().find('.active').removeClass('active');
            $(this).addClass('active');

            app.amimateScroll(top);

            var activeId = $('.graphic_nav').find('li.active').attr('id');
			$('.slider_nav li.active').removeClass('active');
	        $('.slider_nav').find('#'+activeId).addClass('active');

            $('.passion_slider .flexslider').flexslider($(this).index());
        });

        /* Scroll down CTA stuff
        *************************************************/

		/* don't need this to show up all the time...
        $(window).on('scroll', function() {
            clearTimeout($.data(this, 'scrollTimer'));
            if(window.scrollSway){
                $.data(this, 'scrollTimer', setTimeout(function() {
                    $('.scrollmore').fadeIn();
                    ints = 0;
                }, 5000));
            }
        });

	*/

        /* Fancybox calls
        ****************************************************/
        $('.replay').on('click', function(e){
            $('.introVideo').show().delay(500).queue(function(){
                $(this).removeClass('remove');
                $(this).find('iframe').attr('src', 'http://player.vimeo.com/video/64247267?title=0&amp;byline=0&amp;portrait=0&amp;color=e5173f&amp;autoplay=1');
            });

            e.preventDefault();
        })
    };

    app.scrollTimeout = function(){
        scrollSway = window.setInterval(function(){
            if(ints <= 5){
                $('.scrollmore').toggleClass('play');
            }

            ints++;
        }, 5000)
    };

    app.amimateScroll = function(top){
        if (scrolling)
            return false;

        $waypointSelector.waypoint('disable');
        scrolling = true;

        $('html, body').animate({
            scrollTop: top
        }, {
            complete: function () {
                $waypointSelector.waypoint('enable');
                scrolling = false;
            }
        });
    };

    // inital video init
    app.init = function(){
        app.therest();

        $waypointSelector.waypoint(function(direction) {
            var $this = $(this),
                GATitle = $this.attr('id');

            ga('send', 'event', 'Scroll', direction, GATitle);
        });

        // Show logo default if logo query variable is present
        if (app.getQueryVariable('logo') == 'true')
            app.showLogo();

        // Show logo after 30sec
        setTimeout(function () {
            app.showLogo();
        }, 30000);


        // Switch copy-based off changes
        app.swapCopy();

    };

})(jQuery, window.chick || (window.chick = {}), window);

$(function() {
	site.init();
});




// Implements Detaxu Track
function trackPixel(eventName) {
	var trackURL = "http://tags.w55c.net/rs?id=";
	var defaultTrackCode = "b6b0efbba85c4b6994b17298aa9ee49c&t=marketing"; // default for landing
	var trackCode = "";
	var trackCodes = [];

	trackCodes["TakeTheNextStep"] = "b6bbf39cbe284e34a8bba2f082777539&t=marketing";
	trackCodes["FAQs"] = "7afbdc010fe341dcb60b932bf205dc52&t=marketing";
	trackCodes["MakingItYours"] = "c7a1767960f34eb78ac7921a07283ecf&t=marketing";
	trackCodes["IsThisForYou"] = "3ce450bbb8c64ef39af0775d6ef0f575&t=marketing";
	trackCodes["OperatorPaths"] = "c33a8e29a7c14dde8fb633de0c76251f&t=marketing";
	trackCodes["WhyWereDifferent"] = "ec1fb92efadf427f9f99f2869205b14b&t=marketing";
	trackCodes["Microsite_LandingPage"] = "b6b0efbba85c4b6994b17298aa9ee49c&t=marketing";
	trackCodes["Microsite_Video"] = "242aff88613942af8f46b47c3ed9bb44&t=completed_view";
	trackCodes["ImInterestedButton"] = "f0730fa2e322457abd7998422eb868be&t=checkout&tx=$TRANSACTION_ID&sku=$SKUS&price=$price";
  trackCodes["ExpressInterestButton"] = "47e83d948a4a482a9d057428c63540ab&t=checkout&tx=$TRANSACTION_ID&sku=$SKUS&price=$price";
  trackCodes["LetsGetStarted"] = "a5a78ef65dc0423ab0297a000c1d4ce0&t=checkout&tx=$TRANSACTION_ID&sku=$SKUS&price=$price";
	trackCodes["MaybeLater"] = "d37fe356c732443f9fae857657206b63&t=marketing";

	trackCode = trackCodes[eventName];

	if(typeof trackCode === "undefined"){
		trackCode = defaultTrackCode;
	}

    var img = document.createElement("img");
    img.setAttribute("src", trackURL + trackCode);

    document.body.appendChild(img);
  }



// Tracks a view for the currently viewed section
function sectionTracker(){
	if(currentSectionId == lastSectionId){
		trackBySection(currentSectionId);
	}

	if(currentSectionId != ""){
		lastSectionId = currentSectionId;
	} else{
		lastSectionId = "none";
	}

}

// Track view by section id
function trackBySection(id){
	var trackId = [];

	id = id.replace('#','');

	trackId['overview'] = "WhyWereDifferent";
	trackId['persona'] = "OperatorPaths";
	trackId['fit'] = "IsThisForYou";
	trackId['passion'] = "MakingItYours";
	trackId['faqs'] = "FAQs";
	trackId['end'] = "TakeTheNextStep";

	/*
	if(typeof id === "undefined"){
		id="overview";
	}
	*/

	if(sectionTracked[id]!=true){
		trackPixel(trackId[id]);
		//console.log("tracking " + id);
		sectionTracked[id] = true;
	}
}
